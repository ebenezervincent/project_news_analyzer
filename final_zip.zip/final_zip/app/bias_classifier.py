# app/bias_classifier.py
from transformers import pipeline
import torch

# Prefer a smaller, fast NLI model. Fall back gracefully.
_MODEL_NAME = "typeform/distilroberta-base-v2"  # fast NLI variant; if unavailable, try bart
try:
    _device = 0 if torch.cuda.is_available() else -1
except Exception:
    _device = -1

try:
    bias_classifier = pipeline("zero-shot-classification", model=_MODEL_NAME, device=_device)
except Exception:
    bias_classifier = pipeline("zero-shot-classification", model="facebook/bart-large-mnli", device=_device)

_CANDIDATES = ["left", "center", "right"]

def _shorten(text: str, limit: int = 1200) -> str:
    # keep start + end to preserve context
    if not text or len(text) <= limit:
        return text
    head = text[: limit // 2]
    tail = text[-limit // 2 :]
    return f"{head}\n...\n{tail}"

def classify_political_bias(text: str) -> str:
    text = _shorten(text)
    out = bias_classifier(text, _CANDIDATES)
    return out["labels"][0]
from transformers import pipeline

# Load a pre-trained sentiment classifier
bias_classifier = pipeline("zero-shot-classification")


def classify_political_bias(text: str):
    """
    Classify political bias of the text (left, center, right).
    """
    candidate_labels = ["left", "center", "right"]
    result = bias_classifier(text, candidate_labels)

    return result['labels'][0]  # Return the top label as the predicted bias
