# app/api_fetcher.py
from functools import lru_cache
from typing import List, Tuple
from newsdataapi import NewsDataApiClient
import os
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("API_KEY")

# Create the client once
_api = NewsDataApiClient(apikey=API_KEY)

def _keyify_keywords(keywords: List[str]) -> Tuple[str, ...]:
    # normalize + make hashable for caching
    return tuple(sorted({k.strip().lower() for k in keywords if k and k.strip()}))

@lru_cache(maxsize=256)
def fetch_articles_cached(key_tuple: Tuple[str, ...], language="en", country="us", max_pages: int = 2):
    """Cached fetch by normalized, hashable keyword tuple."""
    query = " OR ".join(key_tuple)
    articles, page, pages = [], None, 0

    while pages < max_pages:
        try:
            resp = _api.news_api(q=query, language=language, country=country, page=page) if page else \
                   _api.news_api(q=query, language=language, country=country)
            results = resp.get("results") or []
            for item in results:
                articles.append({
                    "title": item.get("title"),
                    "description": item.get("description"),
                    "url": item.get("link"),
                })
            page = resp.get("nextPage")
            if not page:
                break
            pages += 1
        except Exception:
            break
    return articles

def fetch_articles(keywords: List[str], language="en", country="us", max_pages: int = 2):
    # public wrapper preserves original signature
    return fetch_articles_cached(_keyify_keywords(keywords), language=language, country=country, max_pages=max_pages)
