# app/sentiment_analysis.py
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

_analyzer = SentimentIntensityAnalyzer()

def analyze_sentiment(text: str) -> str:
    if not text:
        return "neutral"
    text = text[:5000]  # trim to keep it snappy
    score = _analyzer.polarity_scores(text)["compound"]
    return "positive" if score >= 0.05 else "negative" if score <= -0.05 else "neutral"
