# app/topic_model.py
import os
import re
from typing import List
from collections import Counter

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
from dotenv import load_dotenv

load_dotenv()
TOPIC_MODE = os.getenv("TOPIC_MODE", "tfidf").lower()

def _fallback_keywords(text: str, top_k: int = 5) -> List[str]:
    """Very fast fallback for short or noisy inputs."""
    tokens = re.findall(r"[a-zA-Z][a-zA-Z\-]{2,}", (text or "").lower())
    tokens = [t for t in tokens if t not in ENGLISH_STOP_WORDS]
    common = [w for w, _ in Counter(tokens).most_common(top_k)]
    return common or ["news", "article", "report", "world", "update"][:top_k]

def _split_sentences(text: str) -> List[str]:
    # simple, fast sentence split; keep only reasonably informative ones
    return [s.strip() for s in re.split(r"[.!?]\\s+", text or "") if len(s.strip()) > 25]

# ------------ Fast TF-IDF keyword extractor ------------
def _tfidf_keywords(text: str, top_k: int = 5) -> List[str]:
    sents = _split_sentences(text)

    # If we don’t have enough sentences, TF-IDF is ill-defined – use fallback.
    if len(sents) < 3:
        return _fallback_keywords(text, top_k=top_k)

    # With few sentences, max_df as a fraction can be < min_df; relax it.
    max_df = 1.0 if len(sents) < 10 else 0.9
    min_df = 1

    vec = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
        max_df=max_df,
        min_df=min_df,
    )

    try:
        X = vec.fit_transform(sents)
    except ValueError:
        # Any corner-case (e.g., all stopwords) → fallback
        return _fallback_keywords(text, top_k=top_k)

    scores = np.asarray(X.mean(axis=0)).ravel()
    vocab = vec.get_feature_names_out()
    top_idx = scores.argsort()[-top_k:][::-1]
    return [vocab[i] for i in top_idx]

# ------------ Optional BERTopic (lazy import) ------------
def _bertopic_keywords(text: str, top_k: int = 5) -> List[str]:
    from bertopic import BERTopic
    from sentence_transformers import SentenceTransformer
    from sklearn.feature_extraction.text import CountVectorizer

    sents = _split_sentences(text)
    if len(sents) < 5:
        return _tfidf_keywords(text, top_k=top_k)

    embedding_model = SentenceTransformer("all-MiniLM-L6-v2")
    topic_model = BERTopic(
        embedding_model=embedding_model,
        vectorizer_model=CountVectorizer(stop_words="english"),
        verbose=False,
    )
    topics, _ = topic_model.fit_transform(sents)
    info = topic_model.get_topic_info()
    top_topic_id = int(info.iloc[1]["Topic"]) if len(info) > 1 else topics[0]
    words = topic_model.get_topic(top_topic_id) or []
    return [" ".join(w for w, _ in words[:top_k])] if words else _tfidf_keywords(text, top_k=top_k)

def extract_topics(text: str, num_topics: int = 1) -> List[str]:
    if not text or len(text) < 200:
        return _fallback_keywords(text, top_k=max(1, num_topics))[:num_topics]

    kws = _bertopic_keywords(text, top_k=5) if TOPIC_MODE == "bertopic" else _tfidf_keywords(text, top_k=5)
    return kws[:max(1, num_topics)]
