import React, { useState } from "react";
import axios from "axios";
import "./App.css";

export default function AnalyzerPage() {
  const [activeTab, setActiveTab] = useState("text"); // "text" | "url"
  const [text, setText] = useState("");
  const [url, setUrl] = useState("");
  const [keywords, setKeywords] = useState([]);
  const [sentiment, setSentiment] = useState("");
  const [bias, setBias] = useState("");
  const [relatedArticles, setRelatedArticles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg("");

    // Basic validation based on active tab
    if (activeTab === "text" && !text.trim()) {
      setErrorMsg("Please paste article text before analyzing.");
      return;
    }
    if (activeTab === "url" && !url.trim()) {
      setErrorMsg("Please enter a valid article URL before analyzing.");
      return;
    }

    setLoading(true);
    try {
      const payload = {
        text: activeTab === "text" ? text : "",
        url: activeTab === "url" ? url : "",
      };

      const response = await axios.post("http://127.0.0.1:8000/process/", payload, {
        headers: { "Content-Type": "application/json" },
      });

      setKeywords(response.data.keywords || []);
      setSentiment(response.data.sentiment || "");
      setBias(response.data.bias || "");
      setRelatedArticles(response.data.related_articles || []);
    } catch (err) {
      console.error("Error processing article:", err);
      setErrorMsg("We couldn’t analyze this input. Please verify the content/URL and try again.");
    } finally {
      setLoading(false);
    }
  };

  const hostFromUrl = (u) => {
    try {
      return new URL(u).hostname.replace("www.", "");
    } catch {
      return "";
    }
  };

  const sentimentClass =
    sentiment === "positive" ? "badge badge--pos"
    : sentiment === "negative" ? "badge badge--neg"
    : sentiment ? "badge badge--neu"
    : "badge";

  const biasClass =
    bias === "left" ? "badge badge--left"
    : bias === "right" ? "badge badge--right"
    : bias ? "badge badge--center"
    : "badge";

  return (
    <div className="nb-wrap">
      <div className="nb-panel glass">
        <header className="nb-panel__head">
          <h1>News Bias & Sentiment</h1>
          <p className="muted">Paste text or a URL. We’ll extract topics, measure sentiment, and estimate political leaning.</p>
        </header>

        {/* Tabs */}
        <div role="tablist" aria-label="Input mode" className="tabs">
          <button
            role="tab"
            aria-selected={activeTab === "text"}
            className={`tab ${activeTab === "text" ? "active" : ""}`}
            onClick={() => setActiveTab("text")}
          >
            Paste Text
          </button>
          <button
            role="tab"
            aria-selected={activeTab === "url"}
            className={`tab ${activeTab === "url" ? "active" : ""}`}
            onClick={() => setActiveTab("url")}
          >
            Paste URL
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="nb-form">
          {activeTab === "text" ? (
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows="10"
              placeholder="Paste your article text here..."
              className="input input--textarea"
            />
          ) : (
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Enter a news URL here…"
              className="input"
            />
          )}

          {errorMsg && <div className="error">{errorMsg}</div>}

          <div className="actions">
            <button type="submit" className={`btn ${loading ? "btn--loading" : ""}`} disabled={loading}>
              {loading ? "Processing…" : "Analyze"}
            </button>
          </div>
        </form>
      </div>

      {/* Results */}
      {(keywords.length || sentiment || bias || relatedArticles.length) ? (
        <section className="nb-results">
          <div className="nb-grid">
            <div className="glass nb-card">
              <h3>Extracted Keywords</h3>
              {keywords.length ? (
                <div className="chips">
                  {keywords.map((k, i) => (
                    <span key={i} className="chip">{k}</span>
                  ))}
                </div>
              ) : (
                <p className="muted">—</p>
              )}
            </div>

            <div className="glass nb-card">
              <h3>Sentiment</h3>
              {sentiment ? <span className={sentimentClass}>{sentiment}</span> : <p className="muted">—</p>}
            </div>

            <div className="glass nb-card">
              <h3>Political Bias</h3>
              {bias ? <span className={biasClass}>{bias}</span> : <p className="muted">—</p>}
            </div>
          </div>

          <div className="glass nb-card nb-card--wide">
            <h3>Related Articles</h3>
            {relatedArticles.length ? (
              <ul className="articles">
                {relatedArticles.map((a, idx) => (
                  <li key={idx} className="article">
                    <a href={a.url} target="_blank" rel="noopener noreferrer" className="article__title">
                      {a.title || a.url}
                    </a>
                    <div className="article__meta">
                      <span className="muted">{hostFromUrl(a.url)}</span>
                    </div>
                    {a.description && <p className="article__desc">{a.description}</p>}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="muted">No related articles returned.</p>
            )}
          </div>
        </section>
      ) : null}
    </div>
  );
}
