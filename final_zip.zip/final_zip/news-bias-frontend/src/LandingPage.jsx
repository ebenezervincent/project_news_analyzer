import React from "react";
import { useNavigate } from "react-router-dom";

// Fully styled, no Tailwind required. Pure CSS with glassmorphism, neon gradients, and bubble animation.
export default function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="nb-root">
      <AnimatedBackground />

      <nav className="nb-nav">
        <div className="nb-nav__brand">
          <div className="nb-logo">📰</div>
          <span>News Bias & Sentiment</span>
        </div>
        <a className="nb-link" href="#how">How it works</a>
      </nav>

      <header className="nb-hero">
        <div className="nb-hero__copy">
          <div className="nb-pill">
            <span className="nb-dot" /> Python backend • React frontend
          </div>
          <h1>
            Understand the <span className="accent-blue">tone</span>,
            <span className="accent-green"> topics</span>, and
            <span className="accent-pink"> bias</span>
            <br /> in any article
          </h1>
          <p>
            Paste a URL or text and our pipeline extracts key topics, measures sentiment, estimates political leaning,
            and surfaces related coverage to help you compare narratives at a glance.
          </p>
          <div className="nb-cta-row">
            <button className="nb-btn nb-btn--primary" onClick={() => navigate("/analyze")}>Analyze article</button>
            <a className="nb-btn nb-btn--ghost" href="#how">See how it works</a>
          </div>
          <div className="nb-badges">
            <span className="nb-badge">BERTopic</span>
            <span className="nb-badge">VADER</span>
            <span className="nb-badge">Zero‑shot</span>
          </div>
        </div>

        <div className="nb-hero__panel">
          <div className="glass nb-card nb-card--shadow">
            <div className="nb-card__header">Sample output</div>
            <pre className="nb-code">{`{
  "keywords": ["earthquake afghanistan relief aftermath", "un aid taliban"],
  "sentiment": "neutral",
  "bias": "center",
  "related_articles": [
    { "title": "Global relief efforts ramp up...", "url": "https://…" },
    { "title": "Aftershocks hinder rescue...", "url": "https://…" }
  ]
}`}</pre>
          </div>
          <div className="nb-stats">
            <div className="nb-stat">
              <div className="nb-stat__value">4</div>
              <div className="nb-stat__label">Pipeline stages</div>
            </div>
            <div className="nb-stat">
              <div className="nb-stat__value"><span className="spark"/>∞</div>
              <div className="nb-stat__label">Articles supported</div>
            </div>
            <div className="nb-stat">
              <div className="nb-stat__value">JSON</div>
              <div className="nb-stat__label">Clean API output</div>
            </div>
          </div>
        </div>
      </header>

      <section className="nb-features" id="features">
        <Feature
          title="Topic Extraction"
          desc="BERTopic + MiniLM finds dominant themes and keywords for precise related‑news search."
          icon="📌"
        />
        <Feature
          title="Sentiment"
          desc="VADER scores text and classifies polarity as positive, negative, or neutral."
          icon="😊"
        />
        <Feature
          title="Political Leaning"
          desc="Zero‑shot classifier estimates left/center/right leaning for quick context."
          icon="⚖️"
        />
      </section>

      <section className="nb-how" id="how">
        <h2>How it works</h2>
        <div className="nb-steps">
          <Step n={1} title="Send content" text={
            <>Frontend sends raw text or a URL to <code>/process</code> on the FastAPI backend.</>
          } />
          <Step n={2} title="Extract + classify" text={
            <>If a URL is provided, the server scrapes the article and runs topic extraction → sentiment → political bias → related news search.</>
          } />
          <Step n={3} title="Return insights" text={
            <>The API returns JSON that the React UI renders with links to comparable coverage.</>
          } />
        </div>
        <div className="nb-center">
          <button className="nb-btn nb-btn--neon" onClick={() => navigate("/analyze")}>Analyze article</button>
        </div>
      </section>

      <footer className="nb-footer">Built with FastAPI, Transformers, BERTopic, and VADER.<br />Vincent © {new Date().getFullYear()}</footer>

      <style>{styles}</style>
    </div>
  );
}

function Feature({ title, desc, icon }) {
  return (
    <div className="nb-feature glass nb-card nb-card--hover">
      <div className="nb-feature__icon" aria-hidden>{icon}</div>
      <div className="nb-feature__title">{title}</div>
      <p className="nb-feature__desc">{desc}</p>
    </div>
  );
}

function Step({ n, title, text }) {
  return (
    <div className="nb-step glass">
      <div className="nb-step__badge">{n}</div>
      <div className="nb-step__body">
        <div className="nb-step__title">{title}</div>
        <div className="nb-step__text">{text}</div>
      </div>
    </div>
  );
}

function AnimatedBackground() {
  return (
    <div aria-hidden className="nb-bg">
      <div className="nb-gradient" />
      <div className="nb-blur nb-blur--1" />
      <div className="nb-blur nb-blur--2" />
      <div className="nb-bubbles">
        {Array.from({ length: 20 }).map((_, i) => (
          <span key={i} style={{"--i": i + 1}} />
        ))}
      </div>
      <div className="nb-vignette" />
    </div>
  );
}

const styles = `
:root{
  --bg: #070a13;
  --card: rgba(255,255,255,0.06);
  --stroke: rgba(255,255,255,0.12);
  --text: rgba(255,255,255,0.88);
  --muted: rgba(255,255,255,0.7);
  --accent-blue: #7bd5ff;
  --accent-green: #7effbf;
  --accent-pink: #ff8bf8;
}
*{box-sizing:border-box}
html,body,#root{height:100%}
body{margin:0;background:var(--bg);color:var(--text);font-family:Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, "Apple Color Emoji","Segoe UI Emoji"}

.nb-root{position:relative;min-height:100vh;overflow-x:hidden}

/* NAV */
.nb-nav{position:relative;z-index:10;max-width:1200px;margin:0 auto;padding:20px 24px;display:flex;justify-content:space-between;align-items:center}
.nb-nav__brand{display:flex;align-items:center;gap:12px;font-weight:700;letter-spacing:.2px}
.nb-logo{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;background:linear-gradient(135deg, rgba(255,255,255,.22), rgba(255,255,255,.06));box-shadow:0 8px 30px rgba(0,0,0,.45);backdrop-filter:blur(6px)}
.nb-link{color:var(--muted);text-decoration:none;border-bottom:1px dashed transparent}
.nb-link:hover{color:#fff;border-bottom-color:rgba(255,255,255,.3)}

/* HERO */
.nb-hero{position:relative;z-index:10;max-width:1200px;margin:0 auto;padding:32px 24px 24px;display:grid;grid-template-columns:1.1fr .9fr;gap:28px}
@media (max-width: 980px){.nb-hero{grid-template-columns:1fr}}

.nb-hero__copy h1{font-size: clamp(32px, 5vw, 60px); line-height:1.05; margin: 10px 0 8px; letter-spacing:-.3px}
.nb-hero__copy p{font-size: clamp(15px, 1.6vw, 18px); color: var(--muted); max-width:680px}
.nb-pill{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border-radius:999px;background:rgba(123,213,255,.09);border:1px solid rgba(123,213,255,.25)}
.nb-dot{width:8px;height:8px;border-radius:999px;background:var(--accent-blue);box-shadow:0 0 16px var(--accent-blue)}
.accent-blue{color:var(--accent-blue)}
.accent-green{color:var(--accent-green)}
.accent-pink{color:var(--accent-pink)}

.nb-cta-row{display:flex;gap:12px;align-items:center;margin-top:18px}
.nb-btn{cursor:pointer;user-select:none;white-space:nowrap;border-radius:14px;padding:12px 18px;font-weight:700;letter-spacing:.2px;transition:transform .08s ease, box-shadow .3s ease, background .3s ease, color .3s ease}
.nb-btn--primary{background:#fff;color:#0b1220;box-shadow:0 10px 30px rgba(123,213,255,.25)}
.nb-btn--primary:hover{transform:translateY(-1px)}
.nb-btn--ghost{background:transparent;color:var(--text);border:1px solid var(--stroke)}
.nb-btn--ghost:hover{background:rgba(255,255,255,.06)}
.nb-btn--neon{background: radial-gradient(120% 120% at 0% 0%, var(--accent-blue), var(--accent-pink)); color:#0b1220; box-shadow:0 12px 40px rgba(255,139,248,.25)}

.nb-badges{margin-top:16px;display:flex;gap:8px;flex-wrap:wrap}
.nb-badge{font-size:12px;padding:6px 10px;border-radius:999px;background:rgba(255,255,255,.06);border:1px solid var(--stroke)}

.nb-hero__panel{display:flex;flex-direction:column;gap:14px}
.glass{background:var(--card);backdrop-filter:blur(10px);border:1px solid var(--stroke);border-radius:20px}
.nb-card{padding:14px}
.nb-card--shadow{box-shadow:0 25px 60px rgba(0,0,0,.45)}
.nb-card--hover{transition:transform .25s ease, box-shadow .25s ease}
.nb-card--hover:hover{transform:translateY(-2px); box-shadow:0 25px 70px rgba(0,0,0,.55)}
.nb-card__header{font-size:12px;color:var(--muted);margin:4px 0 8px}
.nb-code{margin:0;max-height:260px;overflow:auto;padding:14px;border-radius:14px;background:rgba(9,12,22,.8);border:1px solid rgba(255,255,255,.08);color:#e6f0ff}

.nb-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.nb-stat{padding:14px 12px;border-radius:16px;background:linear-gradient(180deg, rgba(255,255,255,.08), rgba(255,255,255,.04));border:1px solid var(--stroke);text-align:center}
.nb-stat__value{font-size:20px;font-weight:800;letter-spacing:.5px}
.nb-stat__label{font-size:12px;color:var(--muted);margin-top:6px}
.spark{display:inline-block;width:10px;height:10px;border-radius:999px;background:linear-gradient(135deg, var(--accent-pink), var(--accent-blue));box-shadow:0 0 16px var(--accent-pink);margin-right:4px}

/* FEATURES */
.nb-features{max-width:1200px;margin:32px auto;padding:6px 24px;display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
@media(max-width:980px){.nb-features{grid-template-columns:1fr}}
.nb-feature{padding:18px}
.nb-feature__icon{font-size:28px;line-height:1}
.nb-feature__title{margin-top:8px;font-weight:800;font-size:18px}
.nb-feature__desc{margin-top:6px;color:var(--muted);line-height:1.6}

/* HOW */
.nb-how{max-width:1200px;margin:10px auto 40px;padding:6px 24px}
.nb-how h2{font-size:30px;margin:12px 0 16px}
.nb-steps{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
@media(max-width:980px){.nb-steps{grid-template-columns:1fr}}
.nb-step{display:flex;gap:14px;padding:16px;border-radius:20px;border:1px solid var(--stroke)}
.nb-step__badge{flex:0 0 36px;height:36px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg, var(--accent-blue), var(--accent-pink));font-weight:800;color:#0b1220}
.nb-step__title{font-weight:800}
.nb-step__text{color:var(--muted);margin-top:4px}
.nb-center{display:flex;justify-content:center;margin-top:18px}

/* FOOTER */
.nb-footer{max-width:1200px;margin:20px auto 80px;padding:0 24px;color:var(--muted);text-align:center}

/* BACKGROUND */
.nb-bg{position:fixed;inset:0;z-index:0;overflow:hidden}
.nb-gradient{position:absolute;inset:-40%;background:radial-gradient(800px 440px at 20% 10%, rgba(123,213,255,.25), transparent 60%),
             radial-gradient(900px 500px at 80% 20%, rgba(255,139,248,.18), transparent 60%),
             radial-gradient(1200px 600px at 50% 90%, rgba(126,255,191,.18), transparent 60%)}
.nb-blur{position:absolute;filter:blur(60px);opacity:.8}
.nb-blur--1{width:380px;height:380px;left:-80px;top:120px;background:linear-gradient(135deg, var(--accent-blue), transparent)}
.nb-blur--2{width:420px;height:420px;right:-60px;top:220px;background:linear-gradient(135deg, var(--accent-pink), transparent)}

.nb-bubbles{position:absolute;inset:0;pointer-events:none}
.nb-bubbles span{position:absolute;bottom:-12vh;width:18px;height:18px;border-radius:50%;
  background:radial-gradient(circle at 30% 30%, rgba(255,255,255,.95), rgba(255,255,255,.08) 60%);
  opacity:.35; left: calc((var(--i) * 7%) % 100%);
  animation: rise calc(11s + var(--i) * .35s) linear infinite, sway calc(6s + var(--i) * .2s) ease-in-out infinite}
.nb-bubbles span:nth-child(3n){opacity:.22}
.nb-bubbles span:nth-child(4n){opacity:.15}
.nb-bubbles span:nth-child(5n){opacity:.3}

@keyframes rise{0%{transform:translateY(0) scale(.8)}100%{transform:translateY(-120vh) scale(1.1)}}
@keyframes sway{0%,100%{transform:translateX(0) rotate(0deg)}50%{transform:translateX(16px) rotate(2deg)}}

.nb-vignette{position:absolute;inset:0;background:radial-gradient(80% 80% at 50% 20%, transparent 40%, rgba(0,0,0,.35)),
             linear-gradient(to bottom, transparent, rgba(0,0,0,.4));}
`;
